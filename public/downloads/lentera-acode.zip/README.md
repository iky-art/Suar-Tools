# Lentera Debug

A self-made debug console for mobile. Lentera watches the file you're currently editing and shows the likely cause of each error directly on your touchscreen, in plain language — not just a raw error message.

## Installation

Easiest way: search for **"Lentera Debug"** directly inside Acode (Settings → Plugins → search "Lentera") — this plugin is officially published on the Acode Plugin Store.

Manual install from ZIP:
1. Open the **Acode** app
2. Go to **Settings** → **Plugins**
3. Tap **+** → select **Local**
4. Select this plugin's zip file
5. Restart Acode if the plugin doesn't activate immediately

## Usage

1. Open any code file in Acode
2. When an error is detected (red underline in the editor), the orange lantern button in the bottom-right corner will **blink**
3. Tap the button to open the Lentera panel
4. The panel lists every error, its line number, and its likely cause

## Folder Contents

```
plugin.json        <- Acode plugin manifest
www/main.js         <- main logic + error-cause dictionary, all in one file
changelogs.md         <- release history
icon.png                <- plugin icon
README.md                 <- this document
```

## Important Notes

- **Acode has moved from Ace to CodeMirror 6.** Lentera currently uses the `editorManager.editor.session` Ace-compatibility layer that Acode provides for legacy plugins — this is officially documented and should keep working, but if that layer is ever removed in a future Acode version, Lentera will need to be rewritten against the native CodeMirror linter/diagnostics API. If Lentera stops detecting errors after an Acode update, this is the most likely cause.
- The error-cause dictionary lives directly inside `main.js` (not a separate file) — this is intentional, since Acode by default only copies `main.js`, `plugin.json`, `readme`, and `icon` when a plugin runs.
- Officially published on the Acode Plugin Store via [acode.app](https://acode.app).

---

## Bahasa Indonesia (opsional)

Lentera Debug adalah console debug buatan sendiri untuk mobile. Lentera memantau error di file yang sedang kamu buka dan menampilkan kemungkinan penyebabnya langsung di layar sentuh — bukan cuma pesan error mentah.

**Cara Install:** cari "Lentera Debug" langsung dari dalam Acode (Settings → Plugins), atau install manual lewat Settings → Plugins → + → Local → pilih file zip ini.

**Cara Pakai:** buka file kode apa saja. Kalau ada error terdeteksi, tombol lentera oranye di pojok kanan bawah akan berkedip — ketuk untuk membuka panel yang menampilkan setiap error, baris berapa, dan kemungkinan penyebabnya.
