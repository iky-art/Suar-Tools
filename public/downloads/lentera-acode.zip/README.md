# Lentera untuk Acode

Console debug buatan sendiri, versi mobile. Lentera memantau error di file yang sedang kamu buka dan menampilkan kemungkinan penyebabnya langsung di layar sentuh.

## Cara Install

Cara termudah: cari **"Lentera"** langsung dari dalam Acode (Settings → Plugins → cari "Lentera") — plugin ini sudah dipublish resmi di Acode Plugin Store.

Kalau mau install manual dari ZIP:
1. Buka aplikasi **Acode** di HP kamu
2. Buka menu **Settings** → **Plugins**
3. Ketuk **+** → pilih **Local**
4. Pilih file zip Lentera ini
5. Restart Acode kalau plugin belum langsung aktif

## Cara Pakai

1. Buka file kode apa saja di Acode
2. Kalau ada error terdeteksi (garis merah di editor), tombol lentera oranye di pojok kanan bawah akan **berkedip**
3. Ketuk tombol itu untuk membuka panel Lentera
4. Panel akan menampilkan setiap error, baris berapa, dan kemungkinan penyebabnya

## Isi Folder Ini

```
plugin.json        <- manifest plugin Acode
www/main.js         <- logic utama + kamus pola error, semua dalam satu file
changelogs.md         <- riwayat rilis
icon.png                <- ikon plugin
README.md                 <- dokumen ini
```

## Catatan Penting

- **Acode sudah pindah dari Ace ke CodeMirror 6.** Lentera saat ini masih memakai lapisan kompatibilitas `editorManager.editor.session` (gaya Ace) yang disediakan Acode untuk plugin lama — ini didokumentasikan resmi dan seharusnya tetap berfungsi, tapi kalau di versi Acode mendatang lapisan ini dihapus, Lentera perlu ditulis ulang pakai API linter/diagnostics CodeMirror native. Kalau Lentera berhenti mendeteksi error setelah update Acode, ini kemungkinan besar penyebabnya.
- Kamus penyebab error ditulis langsung di `main.js` (bukan file terpisah) — ini disengaja, karena Acode secara default cuma meng-copy `main.js`, `plugin.json`, `readme`, dan `icon` saat plugin dijalankan.
- Sudah dipublish resmi di Acode Plugin Store lewat [acode.app](https://acode.app).
