# Lentera untuk Acode

Console debug buatan sendiri, versi mobile. Lentera memantau error di file yang sedang kamu buka dan menampilkan kemungkinan penyebabnya langsung di layar sentuh.

## Cara Install

1. Buka aplikasi **Acode** di HP kamu
2. Buka menu **Settings** → **Plugins**
3. Pilih **Install from .zip**
4. Pilih file zip Lentera ini
5. Restart Acode kalau plugin belum langsung aktif

## Cara Pakai

1. Buka file kode apa saja di Acode
2. Kalau ada error terdeteksi (garis merah di editor), tombol lentera oranye di pojok kanan bawah akan **berkedip**
3. Ketuk tombol itu untuk membuka panel Lentera
4. Panel akan menampilkan setiap error, baris berapa, dan kemungkinan penyebabnya

## Isi Folder Ini

```
lentera-acode/
  plugin.json        <- manifest plugin Acode
  www/main.js         <- logic utama (baca annotation editor, tampilkan panel)
  www/causes.js        <- kamus pola error & saran perbaikan
  README.md            <- dokumen ini
```

## Catatan Penting

- Acode Plugin API bisa berbeda sedikit antar versi Acode. Kode di `main.js` mengikuti pola umum (akses `editorManager` global, `acode.setPluginInit`), tapi kalau ada error saat load plugin, cek dokumentasi resmi Acode Plugin Development untuk menyesuaikan nama API terbaru.
- Plugin ini belum disertai `icon.png` — tambahkan file ikon 512x512 di folder ini dan sesuaikan `plugin.json` sebelum submit ke Acode Plugin Store.
- Untuk publish resmi, submit lewat form developer di situs Acode.
