/**
 * Lentera untuk Acode
 * Memantau annotation error dari editor (Ace) dan menampilkan panel
 * dengan kemungkinan penyebab + saran perbaikan.
 *
 * Catatan: Acode Plugin API bisa berubah antar versi Acode.
 * Struktur di bawah mengikuti pola umum plugin Acode (class dengan init/destroy,
 * akses ke `editorManager` global). Sesuaikan nama API kalau ada perubahan
 * di versi Acode yang kamu pakai — cek acode.app/docs/plugin-development.
 */

class LenteraPlugin {
  constructor() {
    this.$container = null;
    this.$trigger = null;
    this.findings = [];
  }

  async init() {
    this.injectStyles();
    this.createTrigger();
    this.createPanel();
    this.watchEditor();
  }

  watchEditor() {
    const { editorManager } = window;
    if (!editorManager) return;

    const scan = () => this.scanActiveEditor();

    // Scan ulang saat file aktif berganti atau isi berubah
    editorManager.on('switch-file', scan);
    editorManager.on('update', scan);

    scan();
  }

  scanActiveEditor() {
    const { editorManager } = window;
    const session = editorManager?.editor?.session;
    if (!session) return;

    const annotations = session.getAnnotations() || [];
    const errors = annotations.filter((a) => a.type === 'error');

    this.findings = errors.map((e) => {
      const cause = window.LenteraCauses ? window.LenteraCauses.guessCause(e.text) : null;
      return { line: e.row + 1, message: e.text, cause };
    });

    this.render();

    if (this.findings.length > 0) {
      this.$trigger.classList.add('lentera-alert');
    } else {
      this.$trigger.classList.remove('lentera-alert');
    }
  }

  createTrigger() {
    const btn = document.createElement('button');
    btn.className = 'lentera-trigger';
    btn.title = 'Lentera';
    btn.onclick = () => this.togglePanel();
    document.body.appendChild(btn);
    this.$trigger = btn;
  }

  createPanel() {
    const el = document.createElement('div');
    el.className = 'lentera-panel';
    el.innerHTML = `
      <div class="lentera-head">
        <span class="lentera-dot"></span>
        <b>Lentera</b>
        <button class="lentera-close">✕</button>
      </div>
      <div class="lentera-body"><div class="lentera-empty">Belum ada error terdeteksi 🎉</div></div>
    `;
    document.body.appendChild(el);
    el.querySelector('.lentera-close').onclick = () => this.togglePanel(false);
    this.$container = el;
  }

  togglePanel(force) {
    const willOpen = force !== undefined ? force : !this.$container.classList.contains('open');
    this.$container.classList.toggle('open', willOpen);
  }

  render() {
    const body = this.$container.querySelector('.lentera-body');
    if (this.findings.length === 0) {
      body.innerHTML = '<div class="lentera-empty">Belum ada error terdeteksi 🎉</div>';
      return;
    }
    body.innerHTML = this.findings.map((f) => `
      <div class="lentera-entry">
        <div class="lentera-meta">Baris ${f.line}</div>
        <pre>${this.escapeHtml(f.message)}</pre>
        ${f.cause ? `
          <div class="lentera-cause">
            <span class="label">Kemungkinan Penyebab</span>
            ${this.escapeHtml(f.cause.cause)}
            <div class="fix">💡 ${this.escapeHtml(f.cause.fix)}</div>
          </div>
        ` : ''}
      </div>
    `).join('');
  }

  escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }

  injectStyles() {
    const style = document.createElement('style');
    style.textContent = `
      .lentera-trigger{
        position:fixed; right:16px; bottom:70px; width:48px; height:48px;
        border-radius:50%; border:none; z-index:9998;
        background:radial-gradient(circle at 35% 30%, #ffb84d, #ff8a3c 55%, #2a1f14 85%);
        box-shadow:0 0 16px 4px rgba(255,150,60,0.4);
      }
      .lentera-trigger.lentera-alert{
        box-shadow:0 0 20px 6px rgba(224,96,63,0.6);
        animation:lentera-pulse 0.7s ease-in-out infinite;
      }
      @keyframes lentera-pulse{ 0%,100%{transform:scale(1);} 50%{transform:scale(1.1);} }
      .lentera-panel{
        position:fixed; right:12px; bottom:126px;
        width:min(340px, calc(100vw - 24px)); max-height:60vh;
        background:#0d1219; border:1px solid #1e2733; border-radius:14px;
        display:none; flex-direction:column; overflow:hidden; z-index:9999;
        font-family:-apple-system, sans-serif; color:#eef1f5;
        box-shadow:0 20px 50px rgba(0,0,0,0.5);
      }
      .lentera-panel.open{ display:flex; }
      .lentera-head{ display:flex; align-items:center; gap:8px; padding:10px 12px; border-bottom:1px solid #1e2733; }
      .lentera-dot{ width:7px; height:7px; border-radius:50%; background:#ffb84d; }
      .lentera-head b{ font-size:12px; color:#ffb84d; }
      .lentera-close{ margin-left:auto; background:none; border:none; color:#8b95a3; font-size:14px; }
      .lentera-body{ overflow-y:auto; padding:8px 10px; font-size:12px; }
      .lentera-empty{ color:#8b95a3; text-align:center; padding:30px 10px; }
      .lentera-entry{ background:#1a212b; border:1px solid #1e2733; border-left:3px solid #e0603f; border-radius:8px; padding:8px 10px; margin-bottom:8px; }
      .lentera-meta{ color:#8b95a3; font-size:10px; margin-bottom:4px; }
      .lentera-entry pre{ margin:0; white-space:pre-wrap; word-break:break-word; font-family:monospace; font-size:11px; }
      .lentera-cause{ margin-top:6px; background:rgba(255,184,77,0.08); border:1px dashed rgba(255,184,77,0.4); border-radius:6px; padding:6px 8px; }
      .lentera-cause .label{ display:block; text-transform:uppercase; font-size:9px; color:#ffb84d; font-weight:700; margin-bottom:3px; }
      .lentera-cause .fix{ color:#8b95a3; font-size:10.5px; margin-top:4px; }
    `;
    document.head.appendChild(style);
  }

  destroy() {
    this.$trigger?.remove();
    this.$container?.remove();
  }
}

if (window.acode) {
  const lentera = new LenteraPlugin();
  acode.setPluginInit('com.suar.lentera', async (baseUrl, $page, { cacheFileUrl, cacheFile }) => {
    await lentera.init();
  });
  acode.setPluginUnmount('com.suar.lentera', () => {
    lentera.destroy();
  });
}
