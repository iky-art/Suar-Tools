/**
 * Lentera untuk Acode
 * Memantau annotation error dari editor (Ace) dan menampilkan panel
 * dengan kemungkinan penyebab + saran perbaikan.
 *
 * Catatan: Acode Plugin API bisa berubah antar versi Acode.
 * Struktur di bawah mengikuti pola umum plugin Acode (class dengan init/destroy,
 * akses ke `editorManager` global). Sesuaikan nama API kalau ada perubahan
 * di versi Acode yang kamu pakai — cek docs.acode.app.
 *
 * PENTING: Acode hanya meng-copy file main.js, plugin.json, readme, dan icon
 * secara default saat plugin dijalankan — file lain TIDAK ikut ter-copy kecuali
 * didaftarkan di "files" pada plugin.json. Supaya plugin ini tidak rusak karena
 * file pendukung hilang, kamus penyebab error ditulis LANGSUNG di file ini
 * (tidak lagi di file causes.js terpisah).
 */

const LENTERA_CAUSE_PATTERNS = [
  {
    test: /is not a function/i,
    cause: 'Kamu memanggil sesuatu yang bukan fungsi — mungkin nama fungsi salah ketik, belum diimport, atau ke-overwrite oleh variabel lain.',
    fix: 'Cek apakah fungsi ini benar-benar ada di scope ini, dan pastikan tidak ada variabel lain dengan nama sama yang menimpa import-nya.',
  },
  {
    test: /cannot read propert(y|ies) .* of (null|undefined)/i,
    cause: 'Kamu mengakses properti dari nilai null/undefined — objeknya belum ada saat baris ini dijalankan.',
    fix: 'Tambahkan optional chaining (?.) atau pastikan data sudah selesai dimuat sebelum diakses.',
  },
  {
    test: /unexpected token/i,
    cause: 'Ada karakter yang salah tempat — sering terjadi di JSON tidak valid atau kurung/kurawal yang tidak seimbang.',
    fix: 'Cek tanda kutip, koma, dan pasangan kurung di sekitar baris ini.',
  },
  {
    test: /failed to fetch|networkerror|err_name_not_resolved|econnrefused/i,
    cause: 'Permintaan network gagal — domain tidak ditemukan, tidak ada koneksi, server mati, atau diblokir CORS.',
    fix: 'Cek URL benar, cek koneksi, dan cek header CORS di server tujuan.',
  },
  {
    test: /unhandled(promise)? rejection/i,
    cause: 'Ada Promise yang gagal (reject) tapi tidak ditangani.',
    fix: 'Bungkus pemanggilan async ini dengan try/catch, atau tambahkan .catch(err => ...).',
  },
  {
    test: /maximum call stack/i,
    cause: 'Kemungkinan ada fungsi yang memanggil dirinya sendiri tanpa kondisi berhenti (infinite recursion).',
    fix: 'Cek kondisi berhenti (base case) pada fungsi rekursif kamu.',
  },
  {
    test: /module not found|cannot find module/i,
    cause: 'Import mengarah ke file atau package yang tidak ditemukan.',
    fix: 'Cek nama file/path-nya benar, dan pastikan package sudah terinstall (npm install).',
  },
  {
    test: /is not defined/i,
    cause: 'Variabel atau fungsi ini dipakai sebelum dideklarasikan, atau typo pada namanya.',
    fix: 'Cek ejaan nama variabel, dan pastikan sudah dideklarasikan/diimport sebelum baris ini.',
  },
  {
    test: /(expected|missing) (a )?semicolon|declaration or statement expected/i,
    cause: 'Ada bagian sintaks yang belum lengkap — biasanya kurang tanda kurung tutup, koma, atau titik koma.',
    fix: 'Periksa baris ini dan baris sebelumnya untuk tanda baca yang kurang.',
  },
];

function lenteraGuessCause(message) {
  if (!message) return null;
  for (const p of LENTERA_CAUSE_PATTERNS) {
    if (p.test.test(message)) return p;
  }
  return null;
}

class LenteraPlugin {
  constructor() {
    this.$container = null;
    this.$trigger = null;
    this.findings = [];
  }

  async init() {
    this.injectStyles();
    this.createTrigger();
    this.createPanel();
    this.watchEditor();
  }

  watchEditor() {
    const { editorManager } = window;
    if (!editorManager) return;

    const scan = () => this.scanActiveEditor();

    // Scan ulang saat file aktif berganti atau isi berubah
    editorManager.on('switch-file', scan);
    editorManager.on('update', scan);

    scan();
  }

  scanActiveEditor() {
    const { editorManager } = window;
    if (!editorManager) return;

    try {
      // Acode sekarang berjalan di atas CodeMirror 6. editorManager.isCodeMirror
      // bernilai true kalau CodeMirror, null/undefined kalau masih Ace lama.
      // editorManager.editor.session tetap disediakan Acode sebagai lapisan
      // kompatibilitas gaya-Ace untuk plugin lama seperti Lentera ini.
      const session = editorManager.editor?.session;
      if (!session || typeof session.getAnnotations !== 'function') {
        // Lapisan kompatibilitas tidak tersedia di versi Acode ini.
        // Lentera tidak bisa membaca error sampai plugin ini diupdate
        // untuk API CodeMirror native (lihat docs.acode.app/docs/global-apis/ace).
        return;
      }

      const annotations = session.getAnnotations() || [];
      const errors = annotations.filter((a) => a.type === 'error');

      this.findings = errors.map((e) => {
        const cause = lenteraGuessCause(e.text);
        return { line: e.row + 1, message: e.text, cause };
      });

      this.render();

      if (this.findings.length > 0) {
        this.$trigger.classList.add('lentera-alert');
      } else {
        this.$trigger.classList.remove('lentera-alert');
      }
    } catch (err) {
      // Jangan sampai plugin crash total kalau API editor berubah lagi di masa depan.
      console.warn('[Lentera] gagal memindai editor:', err);
    }
  }

  createTrigger() {
    const btn = document.createElement('button');
    btn.className = 'lentera-trigger';
    btn.title = 'Lentera';
    btn.onclick = () => this.togglePanel();
    document.body.appendChild(btn);
    this.$trigger = btn;
  }

  createPanel() {
    const el = document.createElement('div');
    el.className = 'lentera-panel';
    el.innerHTML = `
      <div class="lentera-head">
        <span class="lentera-dot"></span>
        <b>Lentera</b>
        <button class="lentera-close">✕</button>
      </div>
      <div class="lentera-body"><div class="lentera-empty">Belum ada error terdeteksi 🎉</div></div>
    `;
    document.body.appendChild(el);
    el.querySelector('.lentera-close').onclick = () => this.togglePanel(false);
    this.$container = el;
  }

  togglePanel(force) {
    const willOpen = force !== undefined ? force : !this.$container.classList.contains('open');
    this.$container.classList.toggle('open', willOpen);
  }

  render() {
    const body = this.$container.querySelector('.lentera-body');
    if (this.findings.length === 0) {
      body.innerHTML = '<div class="lentera-empty">Belum ada error terdeteksi 🎉</div>';
      return;
    }
    body.innerHTML = this.findings.map((f) => `
      <div class="lentera-entry">
        <div class="lentera-meta">Baris ${f.line}</div>
        <pre>${this.escapeHtml(f.message)}</pre>
        ${f.cause ? `
          <div class="lentera-cause">
            <span class="label">Kemungkinan Penyebab</span>
            ${this.escapeHtml(f.cause.cause)}
            <div class="fix">💡 ${this.escapeHtml(f.cause.fix)}</div>
          </div>
        ` : ''}
      </div>
    `).join('');
  }

  escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }

  injectStyles() {
    const style = document.createElement('style');
    style.textContent = `
      .lentera-trigger{
        position:fixed; right:16px; bottom:70px; width:48px; height:48px;
        border-radius:50%; border:none; z-index:9998;
        background:radial-gradient(circle at 35% 30%, #ffb84d, #ff8a3c 55%, #2a1f14 85%);
        box-shadow:0 0 16px 4px rgba(255,150,60,0.4);
      }
      .lentera-trigger.lentera-alert{
        box-shadow:0 0 20px 6px rgba(224,96,63,0.6);
        animation:lentera-pulse 0.7s ease-in-out infinite;
      }
      @keyframes lentera-pulse{ 0%,100%{transform:scale(1);} 50%{transform:scale(1.1);} }
      .lentera-panel{
        position:fixed; right:12px; bottom:126px;
        width:min(340px, calc(100vw - 24px)); max-height:60vh;
        background:#0d1219; border:1px solid #1e2733; border-radius:14px;
        display:none; flex-direction:column; overflow:hidden; z-index:9999;
        font-family:-apple-system, sans-serif; color:#eef1f5;
        box-shadow:0 20px 50px rgba(0,0,0,0.5);
      }
      .lentera-panel.open{ display:flex; }
      .lentera-head{ display:flex; align-items:center; gap:8px; padding:10px 12px; border-bottom:1px solid #1e2733; }
      .lentera-dot{ width:7px; height:7px; border-radius:50%; background:#ffb84d; }
      .lentera-head b{ font-size:12px; color:#ffb84d; }
      .lentera-close{ margin-left:auto; background:none; border:none; color:#8b95a3; font-size:14px; }
      .lentera-body{ overflow-y:auto; padding:8px 10px; font-size:12px; }
      .lentera-empty{ color:#8b95a3; text-align:center; padding:30px 10px; }
      .lentera-entry{ background:#1a212b; border:1px solid #1e2733; border-left:3px solid #e0603f; border-radius:8px; padding:8px 10px; margin-bottom:8px; }
      .lentera-meta{ color:#8b95a3; font-size:10px; margin-bottom:4px; }
      .lentera-entry pre{ margin:0; white-space:pre-wrap; word-break:break-word; font-family:monospace; font-size:11px; }
      .lentera-cause{ margin-top:6px; background:rgba(255,184,77,0.08); border:1px dashed rgba(255,184,77,0.4); border-radius:6px; padding:6px 8px; }
      .lentera-cause .label{ display:block; text-transform:uppercase; font-size:9px; color:#ffb84d; font-weight:700; margin-bottom:3px; }
      .lentera-cause .fix{ color:#8b95a3; font-size:10.5px; margin-top:4px; }
    `;
    document.head.appendChild(style);
  }

  destroy() {
    this.$trigger?.remove();
    this.$container?.remove();
  }
}

if (window.acode) {
  const lentera = new LenteraPlugin();
  acode.setPluginInit('com.suar.lentera', async (baseUrl, $page, { cacheFileUrl, cacheFile }) => {
    await lentera.init();
  });
  acode.setPluginUnmount('com.suar.lentera', () => {
    lentera.destroy();
  });
}
