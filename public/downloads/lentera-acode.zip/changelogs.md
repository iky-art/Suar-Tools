# Changelog

## v0.2.0

- Rewritten as a fresh listing (new plugin ID) with clearer branding
- English description and README added (required for store review)
- Improved plugin description

## v0.1.1

- Strengthened compatibility with Acode's migration from Ace to CodeMirror 6
- Added defensive checks so the plugin won't crash if the editor API changes

## v0.1.0

- Initial release of Lentera for Acode
- Detects editor errors + likely cause (originally Indonesian-only)
- Floating trigger button, cause-explanation panel
