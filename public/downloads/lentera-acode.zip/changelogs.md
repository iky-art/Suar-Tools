# Changelog

## v0.2.0

- Deskripsi plugin dirombak jadi lebih jelas
- Pembersihan metadata sebelum resubmit ke Acode Plugin Store

## v0.1.1

- Perkuat kompatibilitas dengan migrasi Acode dari Ace ke CodeMirror 6
- Tambah pengecekan defensif supaya plugin tidak crash kalau API editor berubah

## v0.1.0

- Rilis awal Lentera untuk Acode
- Deteksi error di editor + kemungkinan penyebab (Bahasa Indonesia)
- Tombol trigger mengambang, panel penjelasan penyebab
