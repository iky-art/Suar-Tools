# Lentera untuk VS Code

Console debug buatan sendiri. Lentera memindai error di workspace kamu dan menampilkan kemungkinan penyebabnya, bukan cuma pesan error mentah.

## Cara Install

Cara termudah begitu sudah dipublish: buka **Extensions** di VS Code (Ctrl+Shift+X), cari **"Lentera"**, klik **Install**.

## Cara Pakai

1. Command Palette (Ctrl+Shift+P / Cmd+Shift+P)
2. Jalankan **Lentera: Buka Panel**
3. Panel Lentera muncul di sisi editor, menampilkan semua error yang terdeteksi VS Code di workspace kamu, lengkap dengan kemungkinan penyebab dan saran perbaikan
4. Panel otomatis update tiap kali kamu mengedit file dan error berubah
5. **Lentera: Scan File Aktif Sekarang** untuk memindai ulang manual

## Isi Folder Ini

```
lentera-vscode/
  package.json     <- manifest extension
  extension.js      <- logic utama (baca diagnostics VS Code, tampilkan di webview)
  src/causes.js      <- kamus pola error & saran perbaikan
  icon.png             <- ikon buat marketplace
  LICENSE                <- MIT
  README.md                <- dokumen ini
```

## Cara Publish (buat developer)

1. Install alat CLI-nya:
   ```bash
   npm install -g @vscode/vsce
   ```
2. Bikin publisher account & Personal Access Token di [marketplace.visualstudio.com/manage](https://marketplace.visualstudio.com/manage) (login pakai akun Microsoft/Azure DevOps)
3. Login dari terminal:
   ```bash
   vsce login suar
   ```
   (tempel Personal Access Token waktu diminta)
4. Dari dalam folder `lentera-vscode`, publish langsung:
   ```bash
   vsce publish
   ```
   atau kalau cuma mau bikin file `.vsix` dulu tanpa langsung publish:
   ```bash
   vsce package
   ```

## Cara Kerja

Extension ini memakai API bawaan `vscode.languages.getDiagnostics()` — jadi Lentera membaca error yang sudah dideteksi oleh linter/compiler bahasa yang kamu pakai (ESLint, TypeScript, dll), lalu menambahkan penjelasan penyebabnya di atasnya.
