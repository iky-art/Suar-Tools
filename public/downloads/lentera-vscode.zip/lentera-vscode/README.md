# Lentera untuk VS Code

Console debug buatan sendiri. Lentera memindai error di workspace kamu dan menampilkan kemungkinan penyebabnya, bukan cuma pesan error mentah.

## Cara Install

1. Buka VS Code
2. Buka menu **Extensions** (Ctrl+Shift+X / Cmd+Shift+X)
3. Klik ikon **...** di pojok kanan atas panel Extensions → pilih **Install from VSIX...**
4. Kalau kamu masih punya folder mentah (belum di-package jadi .vsix), jalankan dulu:
   ```bash
   npm install -g @vscode/vsce
   cd lentera-vscode
   vsce package
   ```
   Ini akan menghasilkan file `lentera-0.1.0.vsix` yang bisa dipilih di langkah 3.

## Cara Pakai

1. Setelah ter-install, buka Command Palette (Ctrl+Shift+P / Cmd+Shift+P)
2. Jalankan perintah **Lentera: Buka Panel**
3. Panel Lentera akan muncul di sisi editor, menampilkan semua error yang terdeteksi VS Code di workspace kamu, lengkap dengan kemungkinan penyebab dan saran perbaikan
4. Panel akan otomatis update tiap kali kamu mengedit file dan error berubah
5. Untuk memindai ulang manual, jalankan perintah **Lentera: Scan File Aktif Sekarang**

## Isi Folder Ini

```
lentera-vscode/
  package.json     <- manifest extension
  extension.js      <- logic utama (baca diagnostics VS Code, tampilkan di webview)
  src/causes.js      <- kamus pola error & saran perbaikan
  README.md          <- dokumen ini
```

## Catatan Pengembangan

- Extension ini memakai API bawaan `vscode.languages.getDiagnostics()` — artinya Lentera membaca error yang sudah dideteksi oleh linter/compiler bahasa yang kamu pakai (ESLint, TypeScript, dll), lalu menambahkan penjelasan penyebabnya di atasnya.
- Kamus pola error di `src/causes.js` bisa terus ditambah — silakan kembangkan sesuai jenis error yang paling sering kamu temui.
- Untuk publish resmi ke VS Code Marketplace, kamu perlu akun Azure DevOps + publisher id, lalu jalankan `vsce publish`.
