const vscode = require('vscode');
const { guessCause } = require('./src/causes.js');

let panel = null;
let latestFindings = [];

function activate(context) {
  // Scan ulang tiap kali diagnostics (error/warning) berubah di file mana pun
  const diagListener = vscode.languages.onDidChangeDiagnostics((e) => {
    scanAndUpdate();
  });

  const openCmd = vscode.commands.registerCommand('lentera.openPanel', () => {
    createOrShowPanel(context);
    scanAndUpdate();
  });

  const scanCmd = vscode.commands.registerCommand('lentera.scanActiveFile', () => {
    scanAndUpdate();
    if (!panel) createOrShowPanel(context);
  });

  context.subscriptions.push(diagListener, openCmd, scanCmd);
}

function scanAndUpdate() {
  const findings = [];
  const allDiagnostics = vscode.languages.getDiagnostics();

  for (const [uri, diagnostics] of allDiagnostics) {
    for (const d of diagnostics) {
      if (d.severity !== vscode.DiagnosticSeverity.Error) continue;
      const cause = guessCause(d.message);
      findings.push({
        file: uri.fsPath.split('/').pop(),
        line: d.range.start.line + 1,
        message: d.message,
        cause,
      });
    }
  }

  latestFindings = findings;

  if (panel) {
    panel.webview.postMessage({ type: 'update', findings });
  }

  // Nyalakan status bar kecil kalau ada error (opsional, bisa dikembangkan lagi)
  if (findings.length > 0 && !panel) {
    // Buka otomatis panel saat error pertama muncul, biar seperti "lentera nyala"
    // Dikomentari secara default supaya tidak mengganggu — aktifkan kalau mau perilaku otomatis:
    // createOrShowPanel();
  }
}

function createOrShowPanel(context) {
  if (panel) {
    panel.reveal(vscode.ViewColumn.Beside);
    return;
  }

  panel = vscode.window.createWebviewPanel(
    'lentera',
    'Lentera',
    vscode.ViewColumn.Beside,
    { enableScripts: true, retainContextWhenHidden: true }
  );

  panel.webview.html = getHtml();
  panel.webview.postMessage({ type: 'update', findings: latestFindings });

  panel.onDidDispose(() => {
    panel = null;
  });
}

function getHtml() {
  return `<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<style>
  :root{
    --night:#0d1219; --steel:#1a212b; --steel-2:#232c38;
    --fog:#8b95a3; --paper:#eef1f5; --beam:#ffb84d; --beam-hot:#ff8a3c;
    --signal:#4fd6b8; --err:#e0603f; --line:#1e2733;
  }
  body{
    margin:0; padding:16px;
    background:var(--night); color:var(--paper);
    font-family:-apple-system, sans-serif; font-size:13px;
  }
  h2{ font-family:Georgia,serif; font-weight:400; color:var(--beam); margin:0 0 4px; }
  .sub{ color:var(--fog); font-size:12px; margin-bottom:16px; }
  .empty{ color:var(--fog); text-align:center; padding:40px 10px; }
  .entry{
    background:var(--steel); border:1px solid var(--line); border-left:3px solid var(--err);
    border-radius:8px; padding:10px 12px; margin-bottom:10px;
  }
  .entry .meta{ font-size:11px; color:var(--fog); margin-bottom:4px; }
  .entry .msg{ font-family:'SF Mono',monospace; font-size:12px; white-space:pre-wrap; word-break:break-word; }
  .cause{
    margin-top:8px; background:rgba(255,184,77,0.08); border:1px dashed rgba(255,184,77,0.4);
    border-radius:6px; padding:8px;
  }
  .cause .label{ text-transform:uppercase; font-size:10px; color:var(--beam); font-weight:700; display:block; margin-bottom:4px; }
  .cause .fix{ color:var(--fog); font-size:11.5px; margin-top:4px; }
</style>
</head>
<body>
  <h2>Lentera</h2>
  <div class="sub">Error yang ditemukan di workspace kamu.</div>
  <div id="list"><div class="empty">Belum ada error terdeteksi 🎉</div></div>

  <script>
    const listEl = document.getElementById('list');
    window.addEventListener('message', (event) => {
      const { type, findings } = event.data;
      if (type !== 'update') return;
      if (!findings || findings.length === 0) {
        listEl.innerHTML = '<div class="empty">Belum ada error terdeteksi 🎉</div>';
        return;
      }
      listEl.innerHTML = findings.map(f => \`
        <div class="entry">
          <div class="meta">\${f.file}:\${f.line}</div>
          <div class="msg">\${escapeHtml(f.message)}</div>
          \${f.cause ? \`
            <div class="cause">
              <span class="label">Kemungkinan Penyebab</span>
              \${escapeHtml(f.cause.cause)}
              <div class="fix">💡 \${escapeHtml(f.cause.fix)}</div>
            </div>
          \` : ''}
        </div>
      \`).join('');
    });
    function escapeHtml(s){
      return s.replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
    }
  </script>
</body>
</html>`;
}

function deactivate() {}

module.exports = { activate, deactivate };
