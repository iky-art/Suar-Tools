/**
 * causes.js — Kamus pola error Lentera.
 * Dipakai bersama oleh plugin VS Code dan Acode.
 */

const CAUSE_PATTERNS = [
  {
    test: /is not a function/i,
    cause: 'Kamu memanggil sesuatu yang bukan fungsi — mungkin nama fungsi salah ketik, belum diimport, atau ke-overwrite oleh variabel lain.',
    fix: 'Cek apakah fungsi ini benar-benar ada di scope ini, dan pastikan tidak ada variabel lain dengan nama sama yang menimpa import-nya.',
  },
  {
    test: /cannot read propert(y|ies) .* of (null|undefined)/i,
    cause: 'Kamu mengakses properti dari nilai null/undefined — objeknya belum ada saat baris ini dijalankan.',
    fix: 'Tambahkan optional chaining (?.) atau pastikan data sudah selesai dimuat sebelum diakses.',
  },
  {
    test: /unexpected token/i,
    cause: 'Ada karakter yang salah tempat — sering terjadi di JSON tidak valid atau kurung/kurawal yang tidak seimbang.',
    fix: 'Cek tanda kutip, koma, dan pasangan kurung di sekitar baris ini.',
  },
  {
    test: /failed to fetch|networkerror|err_name_not_resolved|econnrefused/i,
    cause: 'Permintaan network gagal — domain tidak ditemukan, tidak ada koneksi, server mati, atau diblokir CORS.',
    fix: 'Cek URL benar, cek koneksi, dan cek header CORS di server tujuan.',
  },
  {
    test: /unhandled(promise)? rejection/i,
    cause: 'Ada Promise yang gagal (reject) tapi tidak ditangani.',
    fix: 'Bungkus pemanggilan async ini dengan try/catch, atau tambahkan .catch(err => ...).',
  },
  {
    test: /maximum call stack/i,
    cause: 'Kemungkinan ada fungsi yang memanggil dirinya sendiri tanpa kondisi berhenti (infinite recursion).',
    fix: 'Cek kondisi berhenti (base case) pada fungsi rekursif kamu.',
  },
  {
    test: /module not found|cannot find module/i,
    cause: 'Import mengarah ke file atau package yang tidak ditemukan.',
    fix: 'Cek nama file/path-nya benar, dan pastikan package sudah terinstall (npm install).',
  },
  {
    test: /is not defined/i,
    cause: 'Variabel atau fungsi ini dipakai sebelum dideklarasikan, atau typo pada namanya.',
    fix: 'Cek ejaan nama variabel, dan pastikan sudah dideklarasikan/diimport sebelum baris ini.',
  },
  {
    test: /(expected|missing) (a )?semicolon|declaration or statement expected/i,
    cause: 'Ada bagian sintaks yang belum lengkap — biasanya kurang tanda kurung tutup, koma, atau titik koma.',
    fix: 'Periksa baris ini dan baris sebelumnya untuk tanda baca yang kurang.',
  },
];

function guessCause(message) {
  if (!message) return null;
  for (const p of CAUSE_PATTERNS) {
    if (p.test.test(message)) return p;
  }
  return null;
}

module.exports = { CAUSE_PATTERNS, guessCause };
